var express = require('express');
var emp = require('../models').Book;
var router = express.Router();



router.get('V1/', function(req, res){
    try
    {
    console.log('Calling API V1');
    
    let data: { firstName: 'JOHN0000',
     lastName: 'MICHAEL000',
      clientId: '9994567' };
        res.status(200).send(data);
    }
    catch(err){
        throw err;
    }

});

router.get('V2/', function(req, res){
    try
    {
   let data: { firstName: 'JOHN',
     lastName: 'MICHAEL',
      clientId: '999-4567' 
    };
        res.status(200).send(data);
    }
    catch(err){
        throw err;
    }
});

module.exports = router;