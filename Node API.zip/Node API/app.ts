var express = require('express');
var app = express();
var bodyParser = require('body-parser');
var env = require('dotenv').load();
var port = process.env.PORT || 8010;

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({
    extended: true
}));

// index path
app.get('V1/', function(req, res){
    console.log('app listening on port: '+port);
    //res.send('tes express nodejs sqlite')
    try
    {
        let data= { firstName: 'JOHN0000',
        lastName: 'MICHAEL000',
         clientId: '9994567'
    };
        res.status(200).send(data);
    }
    catch(err){
        throw err;
    }
});

app.get('V2/', function(req, res){
    console.log('app listening on port: '+port);
    //res.send('tes express nodejs sqlite')
    try
    {
   let data= { firstName: 'JOHN',
     lastName: 'MICHAEL',
      clientId: '999-4567' 
    };
        res.status(200).send(data);
    }
    catch(err){
        throw err;
    }
});


app.listen(port, function(){
    console.log('app listening on port: '+port);
});