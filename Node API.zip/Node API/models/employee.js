module.exports = function(sequelize, Sequalize) {
    var EmployeeSchema = sequelize.define("employee", {
        firstName: Sequalize.STRING,
        lastName: Sequalize.STRING,
        clientId: Sequalize.STRING
    },{
        timestamps: false
    });
    return EmployeeSchema;
}